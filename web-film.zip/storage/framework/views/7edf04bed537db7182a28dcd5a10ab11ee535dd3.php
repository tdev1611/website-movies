
<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-3">

        <div class="row">
            <div class="col-lg-12">
                
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-6 text-center ">
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success w-50" id="notification">
                                        <?php echo session('success'); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger w-50" id="notification">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php if($countries->count()>0): ?>
                        <div class="card-body">
                            <h4 class="card-title"> Quốc gia  (<?php echo e($countries->count()); ?>)</h4>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Tên thể loại</th>
                                            <th scope="col">Mô tả</th>
                                            <th scope="col">Trạng thái</th>
                                            <th scope="col" class="text-right">Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($key + 1); ?></th>
                                                <td><?php echo e($country->title); ?></td>
                                                <td>
                                                    <?php echo e($country->desc); ?>

                                                </td>
                                                <td>
                                                    <?php if($country->status == 1): ?>
                                                        <span class="badge badge-success">Hiện</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-danger">Ẩn</span>
                                                    <?php endif; ?>
                                                </td>

                                                <td class="d-flex justify-content-end">
                                                    <a href="<?php echo e(route('admin.countries.edit', $country->id)); ?>"
                                                        class="btn btn-primary mr-2">Sửa</a>
                                                    <form action="<?php echo e(route('admin.countries.destroy', $country->id)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-danger" type="submit">Xóa</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php else: ?>
                    <span class="text-center my-3">Chưa có bản ghi nào</span>
                    <?php endif; ?>

                </div>
                <!-- #/ container -->
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            setTimeout(function() {
                $('#notification').fadeOut('slow');
            }, 2000);
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project\web-film\resources\views/admin/country/index.blade.php ENDPATH**/ ?>